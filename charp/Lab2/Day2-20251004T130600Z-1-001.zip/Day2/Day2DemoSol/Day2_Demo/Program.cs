﻿namespace Day2_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Value Type
            //int x;
            ////   Int32 x;
            //x = 10;
            //Console.WriteLine(x);
            //int y = x;
            //Console.WriteLine(y); 
            #endregion

            #region Ref Type

            //object O1 = new Object();
            //Console.WriteLine($"before => {O1.GetHashCode()}");

            //object O2 = new object();
            //Console.WriteLine($"{O2.GetHashCode()}");

            //O2 = O1;
            //Console.WriteLine("----------------");
            //Console.WriteLine($"after => {O1.GetHashCode()}");
            //Console.WriteLine($"after => {O2.GetHashCode()}");

            #endregion

            #region String

            //string first = "Ahmed";
            //string last = "Ali";
            //string FullName = "";

            //FullName = first;
            //FullName += " ";
            //FullName += last;

            //int x = 5, y = 10;
            //string msg = String.Format("{0} + {1} = {2} ", x, y, x + y);
            //Console.WriteLine(msg);
            //Console.WriteLine("{0} + {1} = {2} ", x, y, x + y);
            //Console.WriteLine($"{x} + {y} = {x + y}");
            //Console.WriteLine("Hello World from C#");
            //Console.WriteLine(""" 'Hello World' from [C#]""");
            ////FullName.





            #endregion

            #region Casting between Values Type
            //Int32 x = 10;
            //Int64 y = Int64.MaxValue;
            //Console.WriteLine("Before");
            //Console.WriteLine($"X = {x}=>{x.GetType()}");
            //Console.WriteLine($"Y = {y}=>{y.GetType()}");
            ////  y = x; //Implicit Casting [Safe Casting]
            //checked
            //{
            //    x = (int)y; //Explicit Casting [unsafe]

            //}
            //Console.WriteLine("After");
            //Console.WriteLine($"X = {x}=>{x.GetType()}");
            //Console.WriteLine($"Y = {y}=>{y.GetType()}");











            #endregion

            #region Casting Between Value  & Ref
            //Object o1 = new();
            //int x = 10;
            //Console.WriteLine("Before : ");
            //Console.WriteLine(o1);
            //Console.WriteLine(x);
            //// o1 = x; //Boxing
            //x =(int)o1; //unBoxing
            //Console.WriteLine("After : ");
            //Console.WriteLine(o1.ToString());
            //Console.WriteLine(x);



            #endregion

            #region 1D Array
            // int[] arr = {10,20,30}; //ref -> NULL 
            //// arr = new int[4] {1 , 2 , 3 , 4}; //16 Bytes
            // arr = new int[]{1 , 2 , 3 , 4}; //16 Bytes
            // Console.WriteLine(arr.Length); //NULL.Length
            // for(int i = 0; i < arr.Length; i++)
            //     Console.WriteLine(arr[i]);

            // foreach(int num in arr)
            //     Console.WriteLine(num); 
            #endregion

            #region 2D Array

            //int[,] grades;//
            //grades = new int[3, 2] { {100,80 },
            //                         { 50,50},
            //                         {100,80} };
            ////foreach(int i in grades)
            ////    Console.WriteLine(i);
            //Console.WriteLine(grades.Length);
            //Console.WriteLine(grades.GetLength(0));
            //Console.WriteLine(grades.GetLength(1));
            //for (int i =0; i < grades.GetLength(0); i++)
            //{
            //    for(int j =0; j<grades.GetLength(1);j++)
            //    Console.Write($"{grades[i,j]} ,");

            //    Console.WriteLine();
            //}


            #endregion

            #region Array Index & Range
            // int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8 };
            //// //Console.WriteLine(arr[0]);
            //// //Console.WriteLine(arr[7]);
            //// //Console.WriteLine(arr[3]);
            //// //^ index from end
            //// //^0 //Length arr[8] //exception
            //// //^1 //length-1 //arr[^1]
            //// Console.WriteLine(arr[^1]);
            ////// Console.WriteLine(arr[^0]);


            //// Index index = ^2;
            //// Console.WriteLine(arr[index]);

            // int[] arr2 = arr[1..4];


            // arr2 = arr[..^2];
            // arr2 = arr[2..];
            // Range r = ^5..^2;
            // arr2 = arr[r];
            // foreach (int i in arr2)
            // {
            //     Console.WriteLine(i);
            // } 
            #endregion

            #region Nullable Var
            //int ? salary = default;
            //salary = null;
            //Console.WriteLine(salary);
            //int x = 5;
            // salary = 5000;
            ////salary = x;
            //if (salary.HasValue)
            //    //x = (int)salary;
            //x = salary.Value;
            //else
            //    x = -1;
            //    Console.WriteLine(x);

            //x = salary.HasValue ? salary.Value : -1;

            //x = salary ?? -1;

            //int num = 20;
            //if(num % 2 == 0) 
            //    Console.WriteLine("Even");
            //else 
            //    Console.WriteLine("Odd");

            //Console.WriteLine(num % 2 == 0 ? "Even":"Odd"); //Ternary Op

            #endregion




            //object o1 = default;
            //bool b = default;




        }
    }
}
