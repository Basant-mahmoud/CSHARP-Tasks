﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Demo
{
    enum Branches : byte //255
    {
        Banha = 101 , Cairo = 202 , Smart ,Ism = 254, Mnf
    }
}
