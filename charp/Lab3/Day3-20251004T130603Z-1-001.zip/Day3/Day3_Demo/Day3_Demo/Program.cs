﻿namespace Day3_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {


            #region Fun V1
            //PrintLine("(:",1);
            //PrintLine(num:5,pattern:"{ }"); //named Par
            //PrintLine(":(",3);
            //PrintLine(); //Default Paremeter
            //PrintLine("*");
            //PrintLine(num:10); 
            #endregion

            #region Fun V2
            // int A = 10, B = 20;
            ///// int S , M ;
            //// Console.WriteLine(M);

            // SumMul(A, B, out int S, out int M);
            // Console.WriteLine($"sum = {S} , mul = {M}");



            // SumMul(10, 10, out _, out M);
            // Console.WriteLine($"mul = {M}");

            // //Console.WriteLine($"Before=> A = {A} , B = {B}"); //A = 10 , B = 20
            // //Swap(ref A,ref B);
            // //Console.WriteLine($"After=> A = {A} , B = {B}"); //A = 20 , B = 10

            //int A, B;
            //A = 10; B = 20;
            //SwapByOut(out int a, out int b , A , B);

            #endregion

            #region Struct
            //Int32 x;
            //x = 10;
            //Console.WriteLine(x);

            //Int32 xx = new Int32();
            //Console.WriteLine(xx);

            //Student std1 = new Student();
            //std1.setAddress("Cairo");
            //Console.WriteLine("Enter Your Name : ");
            ////string str = Console.ReadLine();

            //std1.name = "ali";
            //std1.age = 22;
            //std1.address = "Alex";

            //std1.setName("ali");
            //std1.setAge(22);
            //std1.setAddress("Cairo");

            //string msg = std1.print();
            //Console.WriteLine(msg);
            //Console.WriteLine(std1.print());
            //Console.WriteLine(std1); 
            #endregion

            Gender r = Gender.Female;
            Branches b = Branches.Smart;

            Branches br = (Branches)202;
            Console.WriteLine(br);
            int x = 1000;
            Gender bb = (Gender)x;

            Console.WriteLine(bb);
            Console.WriteLine(r);
            Console.WriteLine(b);





        }
        static void SumMul(int x , int y , out int Sum , out int Mul)
        {
            //Console.WriteLine(Mul);
            Sum = x + y;
            Mul = x * y;
          //return x + y;
          //return x * y;

        }
        static void SwapByOut(out int x, out int y , int a , int b) //pass by ref
        {
            x = a;
            y = b;
            int temp = x;
            x = y;
            y = temp;
        }
        static void Swap(ref int x,ref int y) //pass by ref
        {
            int temp = x;
            x = y;
            y = temp;
        }
        static void Swap(int x , int y) //pass by value
        {
            int temp = x;
            x = y;
            y = temp;
        }




        static void PrintLine(/*Parameter*/ string pattern="&",int num=5) //Signature 
       {
            for (int i = 0; i < num; i++) //Body
                Console.Write(pattern);
            Console.WriteLine();

        }
    }
}
