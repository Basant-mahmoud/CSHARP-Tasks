﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Demo
{
    struct Student
    {
        //private | public
        //Attributes //member att
        string name;
        int age;
        string address;
        Gender gender;
        //Behaviours //member function

        /// <summary>
        /// //Constructors | Class | use enum 
        /// </summary>
        /// <param name="_name"></param>

        public void setName(string _name)
        {
            name = _name;
           // Console.WriteLine("ay7aga");

        }
        public void setAge(int _age)
        {
           age = _age;
        }
        public void setAddress(string _address)
        {
            address = _address;
        }
        public int getAge()
        {
            return age;
        }
        public string print()
        {
            return $"Studnet Info is -> {name} , {age} , {address}";
        }



    }
}
