﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Demo
{
    enum Gender
    {
        Male = 100 , Female = 1000
    }
}
