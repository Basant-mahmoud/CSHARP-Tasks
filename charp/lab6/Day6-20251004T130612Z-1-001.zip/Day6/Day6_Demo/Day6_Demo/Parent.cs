﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Demo
{
    class Parent
    {
        int x;
        int y;
        public int X { get { return x; } set { x = value; } }
        public int Y { get { return y; } set { y = value; } }
        public virtual void Print()
        {
            Console.WriteLine($"I'am Parent => ({X} , {Y})");
        }
    }
    class child :Parent
    {
        public override void Print()
        {
            Console.WriteLine($"I'am Child => ({X} , {Y})");

        }
    }
}
