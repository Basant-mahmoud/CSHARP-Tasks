﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Demo
{
    class Doctor : Contract
    {
        public int Id { get; set; }

        public double calcBonus(double sal, double bo)
        {
            return sal+bo;
        }

        public int getCount() { return 1000; }

        public string getName()
        {
            return "I'am Doctor";
        }

        public void setName(string _n)
        {
            Console.WriteLine($"Welcome Doctor {_n}"); ;
        }
        public  int anyNum()
        {
            return 10;
        }
        public override string ToString()
        {
            return $"{getCount()},{getName()} , {anyNum()}";
        }
    }
}
