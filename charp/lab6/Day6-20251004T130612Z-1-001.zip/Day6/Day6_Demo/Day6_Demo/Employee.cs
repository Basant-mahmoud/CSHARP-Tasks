﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Demo
{
    class Employee : Contract
    {
    //    public Employee(int _id, int x  )
    //    {
    //        Id = _id;
    //        X = x;
    //    }
        int X;
        public int Id { get; set; }

        public double calcBonus(double sal, double bo)
        {
            return sal+bo+100;
        }

        public int getCount() { return 10; }

        public string getName()
        {
            return $"I'am Employee";
        }

        public void setName(string _n)
        {
            Console.WriteLine($"Welcome ya {_n}"); ;
        }

        public override string ToString()
        {
            return $"{getCount()},{getName()}";
        }
    }
}
