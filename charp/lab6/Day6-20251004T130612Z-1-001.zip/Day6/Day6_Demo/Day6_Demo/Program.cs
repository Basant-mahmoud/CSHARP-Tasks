﻿namespace Day6_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region EX01
            //Parent p = new Parent() { X = 10, Y = 20 };
            //p.Print();

            //child c = new child() { X = 20, Y = 32 };
            //c.Print(); 
            #endregion

            #region Overriding | Abstract 
            //   GeoShape s;// = new GeoShape() { Dim1 = 10, Dim2 = 10 };

            ////   GeoShape s = new GeoShape(10,10) ;
            // s = new Circle(10);
            ////   Console.WriteLine(s.Area()); //100

            //// //  Circle c = new Circle() { Dim1 = 10, Dim2 = 10 };
            ////   Circle c = new Circle(10) ;

            ////   Console.WriteLine(c.Area());//100

            ////  // Tringle t = new Tringle() { Dim1 = 10, Dim2 = 10 };
            ////   Tringle t = new Tringle(10, 10);
            ////   Console.WriteLine(t.Area());//100

            //////   Rect r = new Rect() { Dim1 = 10, Dim2 = 10 };
            ////   Rect r = new Rect(10,10) ;
            ////   Console.WriteLine(r.Area());

            ////   // Square sq = new Square() { Dim1 = 10, Dim2 = 10 };
            ////   Square sq = new Square(10);
            ////   Console.WriteLine(sq.Area());
            //   Console.WriteLine("---------------------------------------");
            //   Circle[] c = new Circle[] { new Circle(10), new(20), new(15) };
            //   Tringle[] t = new Tringle[] { new Tringle(10, 10), new(20, 5) };
            //   Square[] s = new Square[] { new(10) };
            //   Rect[] r = new Rect[] { new(10, 10), new(5, 5), new(6, 6) };

            //   GeoShape[] ss = new GeoShape[] { new Circle(10), new Tringle(20, 20), new Square(22), new Square(20) };

            //   //  Console.WriteLine(SumArea(c, t,s ,r))   ;
            //   Console.WriteLine(SumArea(ss));
            //   Console.WriteLine(SumArea(new Circle(10), new Rect(10,10),new Square(10)));

            //   Console.WriteLine(sum(10, 20 , 30 ,10 , -100)); 
            #endregion

            #region Sealed Class
            //aaaa a = new aaaa();
            //aaaa aa;
            //aa = new(); 
            #endregion

            #region Partial Class
            //Emp e = new Emp();

            //e.Deduction();
            //e.bounS(); 
            #endregion

            #region Interface
            // Employee e = new Employee();

            // //e.Id = 10;
            // //e.setName("Ahmed");
            // //e.calcBonus(10000, 500);
            // //e.getName();
            // //e.getCount();
            // //Console.WriteLine(e.ToString());
            // //Console.WriteLine("-------------------------------");
            // Doctor d = new Doctor();
            // Console.WriteLine(d.anyNum());
            // //d.Id = 100;
            // //d.setName("Mohamed");
            // //d.calcBonus(100000, 5000);
            // //d.getName();
            // //d.getCount();
            // //Console.WriteLine(d);


            // Contract c;//= new Contract();
            // c = new Employee();
            // c.Id = 70;
            // c.setName("Ahmed");
            // c.calcBonus(10000, 500);
            // c.getName();
            // //c.getCount();

            // Console.WriteLine(c.anyNum());

            // Console.WriteLine(c);
            // Console.WriteLine("-------------------------------");
            // c = new Doctor();
            // c.Id = 90;
            // c.setName("Mohamed");
            // c.calcBonus(100000, 5000);
            // c.getName();
            //// c.getCount();
            // Console.WriteLine(c.anyNum());
            // Console.WriteLine(c); 
            #endregion




        }
        public static int sum(params int[] arr)
        {
            int s = 0;
            for (int i = 0; i < arr.Length; i++) s += arr[i];
            return s;
        }
        public static double SumArea(params GeoShape[] s)
        {
            double Sum = 0;
            for (int i = 0; i < s.Length; i++) Sum += s[i].Area();
            return Sum;
        }

        //public static double SumArea(  Circle[] c, Tringle[] t, Square[] s, Rect[] r)
        //{
        //    double Sum = 0;
        //    for(int i = 0; i<c.Length; i++)
        //    {
        //        Sum += c[i].Area();
        //    }
        //    for (int i = 0; i < t.Length; i++)
        //    {
        //        Sum += t[i].Area();
        //    }
        //    for (int i = 0; i < s.Length; i++)
        //    {
        //        Sum += s[i].Area();
        //    }
        //    for (int i = 0; i < r.Length; i++)
        //    {
        //        Sum += r[i].Area();
        //    }
        //    return Sum;
        //}

        //public static double SumArea(Circle c, Tringle t, Circle cc, Square s ,Rect r )
        //{
        //    double Sum = 0;
        //    Sum += c.Area();
        //    Sum += t.Area();
        //    Sum += cc.Area();
        //    Sum += s.Area();
        //    Sum += r.Area();
        //    return Sum;
        //}
    }
}
