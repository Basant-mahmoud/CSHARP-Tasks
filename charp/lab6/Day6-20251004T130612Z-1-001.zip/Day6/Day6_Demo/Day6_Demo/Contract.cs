﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Demo
{
    interface Contract
    {
        int  anyNum()
        {
            return Id;
        }
        
        public int Id { get; set; }
        int getCount();

        void setName(string _n);
        string getName();

        double calcBonus(double sal, double bo);
    }
}
