﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6_Demo
{
    //sealed class aaaa
    //{
    //    int x;
    //}
    //class aa : aaaa
    //{

    //}
    abstract class GeoShape
    {
        public double Dim1 { get; set; }
        public double Dim2 { get; set; }

        public GeoShape(int _x , int _y)
        {
            Dim1 = _x;
            Dim2 = _y;
        }
        public abstract double Area();

        public void  ay7aga()
        {
            Console.WriteLine("Ay7age");
        }
        //{
        //  //  return Dim1 * Dim2;
        //}


    }


    class Rect : GeoShape
    {
        public Rect(int _d1 , int d2):base(_d1 , d2)
        {
            
        }

        public override double Area()
        {
            return Dim1*Dim2;
        }
    }
    class Circle : GeoShape
    {
        public Circle(int r) :  base(r , r)
        {
            
        }
        public override  double Area()
        {
            return (3.14) * Dim1 * Dim2;
        }
    }

    class Tringle : GeoShape
    {
        public Tringle(int _b, int _h) : base(_b, _h)
    {

    }
    public override double Area()
    {
        return (.5) * Dim1 * Dim2;
    }
}
class Square : Rect
{
    public Square(int _d) : base(_d, _d)
    {

    }
}
}
