﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common_
{
   public class Point2D
    {
        int x;      
        int y;

        protected int a;
        internal protected int xxx;

        private protected int yyy;

        public Point2D()
        {
            
        }

        public Point2D(int _x,int _y)
        {
            x = _x;
            y = _y;
        }
        public int X { get { return x; } set { x = value; } }
        internal int Y { get { return y; } set { y = value; } }

        #region Arthematic operatior
        public static Point2D operator +(Point2D left, Point2D right)
        {

            //Point2D res;//= new Point2D(left.X + right.X, left.Y + right.Y);
            //res = new();
            //res.x = left.x + right.x;
            //res.y = left.y + right.y;
            //return res;
            return new Point2D(left.X + right.X, left.Y + right.Y);
        }

        public static Point2D operator *(Point2D left, Point2D right)
        {

            //Point2D res;//= new Point2D(left.X + right.X, left.Y + right.Y);
            //res = new();
            //res.x = left.x + right.x;
            //res.y = left.y + right.y;
            //return res;
            return new Point2D(left.X * right.X, left.Y * right.Y);
        }

        public static Point2D operator /(Point2D left, Point2D right)
        {

            //Point2D res;//= new Point2D(left.X + right.X, left.Y + right.Y);
            //res = new();
            //res.x = left.x + right.x;
            //res.y = left.y + right.y;
            //return res;
            return new Point2D(left.X / right.X, left.Y / right.Y);
        }

        public static Point2D operator %(Point2D left, Point2D right)
        {

            //Point2D res;//= new Point2D(left.X + right.X, left.Y + right.Y);
            //res = new();
            //res.x = left.x + right.x;
            //res.y = left.y + right.y;
            //return res;
            return new Point2D(left.X % right.X, left.Y % right.Y);
        }
        public static Point2D operator -(Point2D left, Point2D right)
        {

            //Point2D res;//= new Point2D(left.X + right.X, left.Y + right.Y);
            //res = new();
            //res.x = left.x + right.x;
            //res.y = left.y + right.y;
            //return res;
            return new Point2D(left.X - right.X, left.Y - right.Y);
        }
        public static Point2D operator ++(Point2D point)
        {
            return new Point2D(point.x + 1, point.y + 1);
        }

        public static Point2D operator --(Point2D point)
        {
            return new Point2D(point.x - 1, point.y - 1);
        }


        #endregion

        public static bool operator > (Point2D l , Point2D r)
        {
            return l.x > r.x && l.y > r.y;
        }

          public static bool operator < (Point2D l , Point2D r)
        {
            return l.x < r.x;
        }
        public static bool operator >= (Point2D l, Point2D r)
        {
            return l.x >= r.x || l.y >= r.y;
        }

        public static bool operator <=(Point2D l, Point2D r)
        {
            return l.x <= r.x && l.y <= r.y;
        }

        public static bool operator ==(Point2D l, Point2D r)
        {
            return l.x == r.x && l.y == r.y;
        }

        public static bool operator !=(Point2D l, Point2D r)
        {
            return l.x != r.x || l.y != r.y;
        }

        public static implicit operator int(Point2D p)
        {
            return p.x;
        }

        //public static explicit operator int(Point2D p) xxxxxxxxxxxx
        //{
        //    return p.x;
        //}
        public static implicit operator string(Point2D p)
        {
            return $"P => ({p.x} . {p.y})";
        }





        public string Print()
        {
            return $"({X} , {Y})";
        }
    }

    public class Ay7aga
    {
        public Ay7aga()
        {
            Point2D p = new();
            p.xxx = 100;
           // p.yyy //xxxxxxxxx
        }
    }
}
