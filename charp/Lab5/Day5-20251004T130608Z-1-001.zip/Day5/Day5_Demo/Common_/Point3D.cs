﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Common_
{
   public class Point3D : Point2D
    {
      protected  int z;
        public int Z { get { return z; } set { z = value; } }
        public string Display()
        {
            return $"{a},{X} , {Y} , {Z} , {xxx} , {yyy}";
        }

    }
}
