﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_Demo
{
    class Employee
    {

        public int Salary { get; set; } 
        public int Age { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }

        public Employee()
        {
            Console.WriteLine("Parent");
        }

        public Employee(int _sal, int _age, string _name, string _address)
        {
            Salary = _sal;
            Age = _age;
            Name = _name;
            Address = _address;
            Console.WriteLine("Parent");

        }
        public int CalcBonus(int value)
        {
            Salary += value;
            return Salary;
        }

        public string Print()
        {
            return $"{Name} , {Salary} , {Address} , {Age}";
        }
    }
}
