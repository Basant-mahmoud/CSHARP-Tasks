﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_Demo
{
    class Person
    {
        int age;
        string name;
        int salary;
        string address;
        //  int count; //memper attr
        static int count = 100;

        static Person()
        {
            count = 100;
        }
        public Person()
        {
           // count = 100;
            count++;
        }
        public Person(string _n , int _a , string _Ad , int _s)
        {
            name = _n;
            address = _Ad;
            salary = _s;
            age = _a;
            count++;
        }

        public static int Counter //read only
        {
            get { return count; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public int   Age
        {
            get { return age; }
            set { age = value; }
        }

        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        public static int getCount() //member function
        {

          //  Console.WriteLine(name); //xxxxxxx
           // print(); //xxxxxx
            return count;
        }

        public string print()
        {
          //  getCount();
          //  count += 100;
            return $"{name} , {age} , {address} , {salary}";
        }
    }
}
