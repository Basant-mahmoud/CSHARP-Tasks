﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_Demo
{
    class Developer : Employee
    {
        public Developer(int _s, string _n) : base(_s, 25, _n, "Ism")
        {
            //Salary = _s;
            //Name = _n;
            Console.WriteLine("Child");
        }
        public void Develop()
        {
            Console.WriteLine("Developing.....");
        }
    }
}
