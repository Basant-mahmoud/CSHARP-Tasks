﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common_;

namespace Day5_Demo
{
    class Point4D : Point3D 
    {
        public int AAA { get; set; }
        public void Print4D()
        {
           // Console.WriteLine($"({a},{X},{Z} , {xxx} , /*{yyy->xxxx}*/)");
        }
    }
}
