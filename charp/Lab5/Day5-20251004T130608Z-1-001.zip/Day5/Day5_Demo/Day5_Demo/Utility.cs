﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5_Demo
{
    static class Utility
    {
        public static double cmToM(double cm)
        {
            return cm / 100;
        }

        public static double mToCM(double m)
        {
            return m * 100;
        }
    }
}
