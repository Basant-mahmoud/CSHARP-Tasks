﻿using Common_;
namespace Day5_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Inhertance
            //Employee emp; //ref null
            //              // emp = new(10000,25,"Ali","Giza");
            //emp = new();
            ////emp.Salary = 10000;
            //emp.CalcBonus(2000);
            ////emp.Name = "Ali ";
            ////emp.Address = "Giza";

            //Console.WriteLine(emp.Print()); ;


            //Developer dev = new Developer(10000,"Ahmed");///////Ctor
            //dev.Name = "Aya";
            //dev.Salary = 15000;
            //dev.CalcBonus(1000);
            //dev.Address = "Ism";
            //Console.WriteLine(dev.Print()); ;



            //Admin adm = new Admin();
            //adm.Address = "Cairo";
            //adm.Name = "Mohamed";
            //adm.Salary = 20000;
            //Console.WriteLine(adm.Print()); ; 
            #endregion

            #region Access Modifier
            //Point2D p2D;
            //p2D = new();

            //p2D.X = 10;

            //Point4D p4D = new();

            #endregion

            #region Static CTOR | Prop|Attr|Method
            //// Console.WriteLine(Person.getCount());
            //Console.WriteLine(Person.Counter);

            //Person p1 = new Person();
            //Console.WriteLine(p1.print());

            //// Console.WriteLine(Person.getCount());
            //Console.WriteLine(Person.Counter);


            //Person p2 = new Person() { Address = "Giza", Age = 30, Name = "Ali", Salary = 5000 };

            //Console.WriteLine(p2.print());
            //// Console.WriteLine(Person.getCount());
            //Console.WriteLine(Person.Counter);


            //Person p3 = new Person("Aya", 25, "Ism", 10000); //call Paramterzed CTOR
            //Console.WriteLine(p3.print());
            //// Console.WriteLine(Person.getCount());
            //Console.WriteLine(Person.Counter);

            #endregion

            #region Static Class
            //  Utility u;// = new Utility();
            //Console.WriteLine(Utility.mToCM(100));
            //Console.WriteLine(Utility.cmToM(1000)); 
            #endregion

            #region Function Overloading
            //Console.WriteLine(Sum(10, 20));
            //Console.WriteLine(Sum(10.5, 20.5));
            //Console.WriteLine(Sum(10.5, 20.5, 10));
            //Console.WriteLine(Sum(10, 20.5, 10.5));
            //Console.WriteLine(Sum("Hello", "World")); 
            #endregion

            int x = 10, y = 20;
            // int z = x++;

            bool z = x > y;

            Point2D p1 = new Point2D(10, 20);
            Point2D p2 = new Point2D(30, 20);
            #region Operator overloading 

            //Arthm.
            Point2D p3 = p1 + p2;
            Console.WriteLine(p3.Print());
            //p3 = p2 - p1;
            //p3 = p1 * p2;
            //p3 = p1 / p2;
            //p3 = p1 % p2;

            //p3 = p1++;
            //Console.WriteLine($"P1=>{p1.Print()} , P3 ={p3.Print()}");
            //p3 = ++p1;
            //Console.WriteLine($"P1=>{p1.Print()} , P3 ={p3.Print()}");

            //p3 = --p2;

            //p3 += p1;//p3 = p3+p1

            //  p3 += 10; //p3 = p3 +int

            //////////////////////Compar.
            ///

            //Console.WriteLine(p1>p2);
            //Console.WriteLine(p1<p2);
            //Console.WriteLine(p1 == p2);
            //Console.WriteLine(p1 >= p2);
            //Console.WriteLine(p1 <= p2);


            ////Casting Operator
            int xx = p1; //
            Console.WriteLine(xx);
            string str = (string)p2;
            Console.WriteLine(str);




            #endregion




        }

        public static int Sum(int x,int y) //Sum(int,int)
        {
            return x + y;
        }
        //public static float Sum(int x, int y) xxxxxxxxxxxxx
        //{
        //    return x + y;
        //}
        public static double Sum(double x, double y)
        {
            return x + y;
        }

        public static string Sum(string x, string y)
        {
            return $"{x} {y}";
        }
        public static int Sum(int x, double y , double z)
        {
            return x ;
        }
        public static double Sum(double x, double y , int c)
        {
            return x + y;
        }

        public static void printLine()
        {
            Console.WriteLine();
        }
    }
}
