﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Demo
{
    class Student //Know About
    {
        public string Name { get; set; }
    }
    class Teacher
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public void Teach(Student std)
        {
            Console.WriteLine($"Dr. {Name} is Teaching {std.Name}");
        }
    }
}
