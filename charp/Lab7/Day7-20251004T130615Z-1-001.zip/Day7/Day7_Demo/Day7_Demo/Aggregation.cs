﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Demo
{
    class Professor
    {
        public string Name { get; set; }
    }
    class Department
    {
        public string Dept_Name { get; set; }
        public List<Professor> professors { get; set; }
    }
}
