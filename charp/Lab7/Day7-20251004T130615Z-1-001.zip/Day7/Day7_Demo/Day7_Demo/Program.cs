﻿namespace Day7_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Association
            //Teacher t = new Teacher();
            //t.Name = "Ali";
            //t.Id = 1;

            //Student s = new Student();
            //s.Name = "Aya";

            //t.Teach(s); 
            #endregion

            #region Aggregation
            //    Professor p = new() { Name = "Mohamed" };

            //    Department d = new Department() { Dept_Name = "SD" };
            //    d.professors = null;
            //    d.professors.Add(p);

            #endregion


            //bool x = int.TryParse(Console.ReadLine(),out int res);
            //Console.WriteLine(x);
            //Console.WriteLine(res);

            //int a = 0;
            //int z = 0 ;
            //if(a != 0)
            //  z = 10 / a;
            //else
            //    Console.WriteLine("Not Valid");


            //    Console.WriteLine(z);

            try
            {
                int z = 0,a=0;
               // z = 10 / a;
              //  int[] arr;
               // arr = default;
               // Console.WriteLine(arr.Length);
                int x = int.Parse(Console.ReadLine());
            }
            catch(CustomException EX)
            {
                throw; 
                throw EX;
                throw new CustomException("this is custom exception");
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
                
            }
            catch(NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("ay7aga");
            }


            Console.WriteLine("sdfghjkl;'sdfghjkl;");

        }
     }
 }
