﻿using Day3_Demo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4_Demo
{
    class StudentClass  //internal[Default] | public 
    {
        //private | public
        //Attributes //member att
        string name;
       int age;
       string address;
       Gender gender;

        #region CTORs
        ////CTOR
        public StudentClass() //Paramterless CTOR
        {
            age = 10;
            name = "Alyaa";
            address = "Giza";
            gender = Gender.Female;
        }
        public StudentClass(string _name, int _age, string _address, Gender _gender) : this(_name, _age, _address)//Parmterized CTOR
        {
            //  name = _name;
            //  age = _age;
            //   address = _address;
            gender = _gender;
        }
        public StudentClass(string _name, int _age, string _address) : this(_name, _age)//Parmterized CTOR
        {
            //  name = _name;
            //   age = _age;
            address = _address;

        }
        public StudentClass(string _name, int _age) : this(_name) //Parmterized CTOR
        {
            //name = _name;
            //this.name = name;
            age = _age;


        }
        public StudentClass(string _name) //Parmterized CTOR
        {
            name = _name;
        }

        #endregion


        #region Setters & Getters
        //Behaviours //member function
        public void setGender(Gender _gender)
        {
            gender = _gender;
        }
        public void setName(string _name)
        {
            name = _name;
            // Console.WriteLine("ay7aga");

        }
        public void setAge(int _age)
        {
            if (_age > 60) age = 0;
            else age = _age;
        }
        public void setAddress(string _address)
        {
            address = _address;
        }
        public int getAge()
        {
            return age;
        }
        #endregion

        #region Properties
        ///Properties
        public string Name //_setName(string value){name = value;} , _getName(){return name;}
        {
            get { return name; }
            set { name = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public int Age
        {
            get { return age; }
            set
            {
                if (value > 60) age = 0;
                else age = value;
            }
        }

        public Gender Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        #endregion

        #region Auto Prop //int _BackingFieldCount; _setCount(int value)=> _BackingFieldCount=value , _getCount()=>return _BackingFieldCount;
        public int Count { get; set; }

        #endregion

        public string print()
        {
            return $"Studnet Info is -> {name} , {age} , {address} , {gender} , {Count}";
        }
    }
}
