﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3_Demo
{
    struct Student
    {
        //private | public
        //Attributes //member att
        string name;
        int age;
        string address;
        Gender gender;

        //CTOR
        public Student() //Paramterless CTOR
        {
            age = 10;
            name = "Alyaa";
            address = "Giza";
            gender = Gender.Female;
        }
        public Student(string _name, int _age, string _address,Gender _gender):this(_name,_age,_address)//Parmterized CTOR
        {
          //  name = _name;
          //  age = _age;
         //   address = _address;
            gender = _gender;
        }
        public Student(string _name, int _age, string _address):this(_name,_age)//Parmterized CTOR
        {
          //  name = _name;
          //   age = _age;
            address = _address;
           
        }
        public Student(string _name, int _age):this(_name) //Parmterized CTOR
        {
            //name = _name;
            //this.name = name;
            age = _age;
            

        }
        public Student(string _name) //Parmterized CTOR
        {
            name = _name;
        }


        //Behaviours //member function

        /// <summary>
        /// //Constructors | Class | use enum 
        /// </summary>
        /// <param name="_name"></param>
        public void setGender(Gender _gender)
        {
            gender = _gender;
        }
        public void setName(string _name)
        {
            name = _name;
           // Console.WriteLine("ay7aga");

        }
        public void setAge(int _age)
        {
           age = _age;
        }
        public void setAddress(string _address)
        {
            address = _address;
        }
        public int getAge()
        {
            return age;
        }
        public string print()
        {
            return $"Studnet Info is -> {name} , {age} , {address} , {gender}";
        }



    }
}
