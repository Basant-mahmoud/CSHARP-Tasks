﻿using ClassLibrary1;
using Day3_Demo;

namespace Day4_Demo
{
    internal class Program
    {
        static void Main(string[] args)
        {

            #region Struct | CTORs EX01
            //Student Std = new Student(); //Default CTOR [Paramterless CTOR] --public Studnet(){ age=default;name=default;address=default;gender=default}
            ////Std.age = 22;
            ////Std.address = "Giza";
            ////Std.name = "Ali";
            ////Std.gender = Gender.Male;
            //Console.WriteLine(Std.print());
            //Std.setName("Ali");
            //Std.setAge(22);
            //Std.setAddress("Giza");
            //Std.setGender(Gender.Male);
            //Student Std1 = new Student("Ahmed", 25, "Giza", Gender.Male); 
            //Console.WriteLine(Std1.print());

            //Student Std2 = new Student("Aya", 28, "Cairo");
            //Console.WriteLine(Std2.print());

            //Student Std3 = new Student("Youssef", 15);
            //Console.WriteLine(Std3.print());

            //Student Std4 = new Student("Mahmoud");
            //Console.WriteLine(Std4.print());

            #endregion

            #region Class | CTORs
            //StudentClass std;  //ref => null
            //std = new StudentClass("Lamyaa"); //Default CTOR
            //Console.WriteLine(std.print());
            //StudentClass std1 = new StudentClass();
            //Console.WriteLine(std1.print());
            //std.gender = Gender.Male;
            //std.age = 26;
            //std.name = "Ali";
            //std.address = "Cairo";
            //Console.WriteLine("-------------------------------");
            //std.setName("Ali");
            //std.setAge(22);
            //std.setAddress("Cairo");
            //std.setGender(Gender.Male);
            #endregion


            #region Class | Prop
            //StudentClass std = new StudentClass();
            //std.Count = 100;
            //Console.WriteLine(std.print());
            //// std.setAddress("Giza");
            ////    std.setAge(25);
            ////std.setGender(Gender.Female);
            ////std.setName("Heba");
            //std.Address = "Ism";
            //std.Count = -1000;            //Console.WriteLine(std.Address);
            // std.Age = 25;
            //std.Gender = Gender.Female;
            //std.Name = "Heba";
            //Console.WriteLine(std.print()); 
            #endregion

            Ay7aga a = new Ay7aga();
            Console.WriteLine( a.getXX());

           /// testFromLib tt = new testFromLib();
        }
    }
}
