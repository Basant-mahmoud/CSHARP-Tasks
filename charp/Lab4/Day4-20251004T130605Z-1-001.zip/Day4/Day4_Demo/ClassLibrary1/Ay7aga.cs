﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Ay7aga
    {
        public int XX { get; set; }
        public int getXX()
        {
            return 100;
        }
        public void AccesstestFromLib()
        {
            testFromLib t = new testFromLib();
            Console.WriteLine(t.Id);
        }
    }
}
