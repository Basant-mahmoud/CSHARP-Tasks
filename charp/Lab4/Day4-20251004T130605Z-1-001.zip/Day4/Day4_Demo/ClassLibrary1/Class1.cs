﻿namespace ClassLibrary1
{
    internal class testFromLib
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
    }
}
